
package pkginterface;

import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;

public class GerenteDeJanela {
    
    private static JDesktopPane jDesktopPane;
    
    public GerenteDeJanela(JDesktopPane jDesktopPane){
        GerenteDeJanela.jDesktopPane = jDesktopPane;
    }
    
    public void abrirJanela (JInternalFrame jInternalFrame){
        if (jInternalFrame.isVisible()){
            jInternalFrame.toFront();
            jInternalFrame.requestFocus();
        }
        else{
            jDesktopPane.add(jInternalFrame);
        }
    }
    
}
